<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'PortalBerita - Berita Terbaru Hari Ini')</title>
    @yield('meta')
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="top-header">
        <div class="container top-wrapper">
            <div class="left-top">
                <i class="fa-solid fa-calendar-days"></i>
                <span id="tanggal">{{ now()->translatedFormat('l, d F Y') }}</span>
            </div>
            <div class="right-top" aria-label="Media sosial">
                <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
                <a href="#" aria-label="X"><i class="fa-brands fa-x-twitter"></i></a>
                <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
            </div>
        </div>
    </div>

    <header class="site-header">
        <div class="container header-content">
            <a class="brand" href="{{ route('home') }}" aria-label="PortalBerita">
                <img src="{{ asset('images/logo.svg') }}" alt="PortalBerita">
            </a>

            <form class="search-box" role="search" action="{{ route('search') }}">
                <input type="search" name="q" value="{{ request('q') }}" placeholder="Cari berita..." aria-label="Cari berita">
                <button type="submit" aria-label="Cari"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>

            <button class="live-button" type="button">
                <i class="fa-solid fa-circle"></i>
                LIVE
            </button>

            <div class="profile">
                <button id="loginBtn" class="profile-btn" type="button" aria-label="Buka menu akun">
                    <i class="fa-regular fa-user"></i>
                </button>
                <div id="profilePopup" class="profile-popup" aria-hidden="true">
                    <div class="popup-header"><i class="fa-regular fa-circle-user"></i></div>
                    <div class="popup-body">
                        <h3>Masuk ke akun Anda</h3>
                        <p>Area pengelola berita<br><a href="{{ route('login') }}">Login Admin</a></p>
                        <hr>
                        <a href="#">Pedoman Media Siber</a>
                        <a href="{{ route('contact') }}">Hubungi Kami</a>
                        <a href="#">Privacy Policy</a>
                        <a href="#">Redaksi</a>
                    </div>
                </div>
            </div>

            <button class="menu-btn" type="button" aria-label="Buka menu">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>

        <nav class="navbar" aria-label="Navigasi utama">
            <ul>
                <li><a href="{{ route('home') }}">Home</a></li>
                @foreach($navCategories as $navCategory)
                    <li><a href="{{ route('category.show', $navCategory) }}">{{ $navCategory->name }}</a></li>
                @endforeach
                <li><a href="{{ route('about') }}">Tentang</a></li>
                <li><a href="{{ route('contact') }}">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <main>
        @yield('content')
    </main>

    <footer>
        <div class="container footer-grid">
            <div>
                <img src="{{ asset('images/logo-white.svg') }}" alt="PortalBerita" class="footer-logo">
                <p>PortalBerita menyajikan berita terpercaya, cepat, dan akurat setiap hari.</p>
            </div>
            <div>
                <h3>Kategori</h3>
                @foreach($navCategories->take(5) as $category)
                    <a href="{{ route('category.show', $category) }}">{{ $category->name }}</a>
                @endforeach
            </div>
            <div>
                <h3>Informasi</h3>
                <a href="{{ route('about') }}">Tentang</a>
                <a href="{{ route('contact') }}">Kontak</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Pedoman Media Siber</a>
            </div>
            <div>
                <h3>Ikuti Kami</h3>
                <div class="footer-social">
                    <i class="fa-brands fa-facebook" aria-label="Facebook"></i>
                    <i class="fa-brands fa-instagram" aria-label="Instagram"></i>
                    <i class="fa-brands fa-youtube" aria-label="YouTube"></i>
                    <i class="fa-brands fa-x-twitter" aria-label="X"></i>
                    <i class="fa-brands fa-tiktok" aria-label="TikTok"></i>
                </div>
            </div>
        </div>
        <div class="copyright">&copy; 2026 PortalBerita. All Rights Reserved.</div>
    </footer>

    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
